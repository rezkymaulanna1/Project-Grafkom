// === SCENE, CAMERA, RENDERER ===
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x333333);
//Gunakan proyeksi perspektif (gluPerspective
const camera = new THREE.PerspectiveCamera(
  75, window.innerWidth / window.innerHeight, 0.1, 1000
);
//Mengatur posisi kamera (gluLookAt)
camera.position.set(3, 3, 5);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// === LIGHTING ===
const ambient = new THREE.AmbientLight(0xffffff, 0.4);
const directional = new THREE.DirectionalLight(0xffffff, 0.8);
directional.position.set(2, 2, 2);
scene.add(ambient, directional);

// === buat CUBE  ===
const geometry = new THREE.BoxGeometry(1, 1, 1);
const material = new THREE.MeshPhongMaterial({
  color: 0xA0522D,     // Coklat seperti kardus
  shininess: 60        // Efek specular (mengkilap)
});
const cube = new THREE.Mesh(geometry, material);
scene.add(cube);

// === STATE ===
let rotateY = false;
let rotateX = false;
let lightingDimmed = false;

const initial = {
  position: cube.position.clone(),
  rotation: cube.rotation.clone(),
  scale: cube.scale.clone()
};

// === KEYBOARD EVENTS ===
document.addEventListener('keydown', (e) => {
  switch (e.key) {
    case 'r': rotateY = true; break;
    case 's': rotateX = true; break;
    case 'p':
      cube.position.copy(initial.position);
      cube.rotation.copy(initial.rotation);
      cube.scale.copy(initial.scale);
      break;
    case 'z':
      cube.scale.multiplyScalar(0.8); break;
    case '+':
    case '=':
      camera.position.z -= 0.5; break;
    case '-':
      camera.position.z += 0.5; break;
    case 'l':
      ambient.visible = directional.visible = !ambient.visible;
      break;
    case 'k':
      if (!lightingDimmed) {
        ambient.intensity = 0.1;
        directional.intensity = 0.2;
      } else {
        ambient.intensity = 0.4;
        directional.intensity = 0.8;
      }
      lightingDimmed = !lightingDimmed;
      break;
      //tranlasi buat gerakin pakai anak panah
    case 'ArrowLeft': cube.position.x -= 0.1; break;
    case 'ArrowRight': cube.position.x += 0.1; break;
    case 'ArrowUp': cube.position.y += 0.1; break;
    case 'ArrowDown': cube.position.y -= 0.1; break;
  }
});
//Transformasi Objek 3D
document.addEventListener('keyup', (e) => {
  if (e.key === 'r') rotateY = false;
  if (e.key === 's') rotateX = false;
});

// === ZOOM IN (double click objek) ===
document.addEventListener('dblclick', () => {
  cube.scale.multiplyScalar(1.25);
});

// === ANIMATION LOOP ===
function animate() {
  requestAnimationFrame(animate);
  if (rotateY) cube.rotation.y += 0.02;
  if (rotateX) cube.rotation.x += 0.02;
  renderer.render(scene, camera);
}
animate();

// === HANDLE WINDOW RESIZE ===
window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
